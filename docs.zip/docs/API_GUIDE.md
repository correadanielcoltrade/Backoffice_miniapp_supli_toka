# Guía de uso de las APIs · Back Office Mini App Toka

Esta guía explica cómo **consultar información** a través de las APIs del back
office. Hay **dos APIs distintas**, cada una con su forma de autenticarse:

| API | Ruta base | Para quién | Autenticación |
|-----|-----------|------------|----------------|
| **Interna** | `/api/` | Equipo del back office (Administrador, Procurement, Logistic, Sales) | **JWT** (usuario + contraseña) |
| **Pública** | `/api/public/v1/` | Empresas/desarrolladores externos | **API Key** (`X-API-Key`) |

> URL base en desarrollo: `http://127.0.0.1:8000`
> Sustituye por tu dominio real en producción.

---

## Documentación interactiva (Swagger)

Hay documentación viva y navegable generada automáticamente:

- **Swagger UI:** `http://127.0.0.1:8000/api/docs/`
- **Esquema OpenAPI:** `http://127.0.0.1:8000/api/schema/`

> 🔒 Están **protegidas**: solo se ven si has iniciado sesión en el admin de
> Django (`/admin/`). Un usuario anónimo recibe **401**.

---

# 1. API Interna (con JWT)

Todos los módulos exigen login. El flujo es: **te logueas → recibes un token →
lo mandas en cada petición**.

## 1.1 Iniciar sesión y obtener el token

```bash
curl -X POST http://127.0.0.1:8000/api/auth/token/ \
     -H "Content-Type: application/json" \
     -d '{"username": "Danielcorrea", "password": "TU_PASSWORD"}'
```

Respuesta:

```json
{
  "access": "eyJhbGciOiJIUzI1NiI...",
  "refresh": "eyJhbGciOiJIUzI1NiI...",
  "user": {
    "id": 1,
    "username": "Danielcorrea",
    "role": "ADMINISTRADOR",
    "role_display": "Administrador"
  }
}
```

- `access`: token de acceso (dura 60 min). Se usa en cada petición.
- `refresh`: sirve para obtener un nuevo `access` sin volver a loguearte (dura 7 días).

## 1.2 Consultar información con el token

Se envía el `access` en el header `Authorization: Bearer <token>`:

```bash
curl http://127.0.0.1:8000/api/products/ \
     -H "Authorization: Bearer eyJhbGciOiJIUzI1NiI..."
```

## 1.3 Renovar el token cuando expira

```bash
curl -X POST http://127.0.0.1:8000/api/auth/token/refresh/ \
     -H "Content-Type: application/json" \
     -d '{"refresh": "eyJhbGciOiJIUzI1NiI..."}'
```

## 1.4 Endpoints internos para CONSULTAR información

Todos aceptan `GET` para listar y `GET /<id>/` para el detalle.

| Recurso | Endpoint | Rol que puede acceder |
|---------|----------|------------------------|
| Usuarios | `GET /api/users/` | Administrador |
| Mi usuario | `GET /api/users/me/` | Cualquiera logueado |
| Roles disponibles | `GET /api/users/roles/` | Administrador |
| Categorías | `GET /api/categories/` | Procurement |
| Productos | `GET /api/products/` | Procurement |
| Inventario | `GET /api/inventory/` | Procurement, Logistic |
| Movimientos de stock | `GET /api/stock-movements/` | Procurement, Logistic |
| Clientes | `GET /api/customers/` | Sales, Logistic |
| Direcciones de clientes | `GET /api/customer-addresses/` | Sales, Logistic |
| Pedidos | `GET /api/orders/` | Sales, Logistic |
| Pagos | `GET /api/payments/` | Sales, Logistic |
| Devoluciones | `GET /api/returns/` | Logistic |
| Carruseles de ads | `GET /api/carousels/` | Sales |
| Resumen / KPIs | `GET /api/reports/summary/` | Cualquiera logueado |

> El **Administrador** puede acceder a todos los módulos.

### Filtrar, buscar y ordenar

Los listados aceptan parámetros por query string:

```bash
# Buscar productos por texto (descripción o SKU)
GET /api/products/?search=teclado

# Filtrar productos por categoría
GET /api/products/?category=3

# Filtrar pedidos por estado
GET /api/orders/?status=PAID

# Ordenar por precio ascendente
GET /api/products/?ordering=sale_price

# Paginación (20 por página por defecto)
GET /api/products/?page=2
```

Respuesta de un listado (paginada):

```json
{
  "count": 42,
  "next": "http://127.0.0.1:8000/api/products/?page=2",
  "previous": null,
  "results": [ { "id": 1, "sku": "TEC-001", "description": "Teclado", "...": "..." } ]
}
```

---

# 2. API Pública (con API Key)

Pensada para que **externos consulten el catálogo**. Es de **solo lectura** y no
expone usuarios, pagos ni datos personales.

## 2.1 Obtener una API Key

La emite el equipo del back office (no es autoservicio):

```bash
python manage.py create_api_client "Nombre de la empresa" --email contacto@empresa.com --rate 120
```

Devuelve una clave del tipo `tok_xxxxxxxxxxxxxxxxxxxx` **que se muestra una sola vez**.

## 2.2 Consultar información

Se envía la clave en el header `X-API-Key`:

```bash
# Listar productos activos
curl http://127.0.0.1:8000/api/public/v1/products/ \
     -H "X-API-Key: tok_xxxxxxxxxxxxxxxxxxxx"

# Detalle de un producto por SKU
curl http://127.0.0.1:8000/api/public/v1/products/TEC-001/ \
     -H "X-API-Key: tok_xxxxxxxxxxxxxxxxxxxx"

# Categorías
curl http://127.0.0.1:8000/api/public/v1/categories/ \
     -H "X-API-Key: tok_xxxxxxxxxxxxxxxxxxxx"

# Carruseles de ads activos
curl http://127.0.0.1:8000/api/public/v1/carousels/ \
     -H "X-API-Key: tok_xxxxxxxxxxxxxxxxxxxx"
```

## 2.3 Endpoints públicos

| Recurso | Endpoint | Descripción |
|---------|----------|-------------|
| Productos | `GET /api/public/v1/products/` | Catálogo de productos activos |
| Producto (detalle) | `GET /api/public/v1/products/<sku>/` | Por SKU |
| Categorías | `GET /api/public/v1/categories/` | Categorías activas |
| Carruseles | `GET /api/public/v1/carousels/` | Ads activos |

Ejemplo de respuesta de un producto:

```json
{
  "id": 1,
  "sku": "TEC-001",
  "description": "Teclado mecánico",
  "category": "Periféricos",
  "sale_price": "899.00",
  "images": ["http://.../image1.jpg", "http://.../image2.jpg"],
  "available": true,
  "units_in_stock": 25
}
```

## 2.4 Límite de peticiones (rate limit)

Cada consumidor tiene un límite por minuto (por defecto 60/min). Al excederlo se
recibe **429 Too Many Requests**. Se puede subir el límite por consumidor.

## 2.5 Ejemplo en otros lenguajes

**JavaScript (fetch):**

```javascript
const res = await fetch("http://127.0.0.1:8000/api/public/v1/products/", {
  headers: { "X-API-Key": "tok_xxxxxxxxxxxxxxxxxxxx" },
});
const data = await res.json();
console.log(data.results);
```

**Python (requests):**

```python
import requests

r = requests.get(
    "http://127.0.0.1:8000/api/public/v1/products/",
    headers={"X-API-Key": "tok_xxxxxxxxxxxxxxxxxxxx"},
)
print(r.json())
```

---

# 3. Códigos de respuesta

| Código | Significado | Causa típica |
|--------|-------------|--------------|
| `200` | OK | Consulta exitosa |
| `201` | Creado | Se creó un recurso (POST) |
| `400` | Solicitud inválida | Datos mal formados |
| `401` | No autenticado | Falta el token/API Key o es inválido |
| `403` | Sin permiso | Tu rol no puede acceder a ese módulo |
| `404` | No encontrado | El recurso no existe |
| `429` | Demasiadas peticiones | Superaste el rate limit (API pública) |

---

# 4. Resumen de seguridad

- **Sin login no se accede a ningún módulo interno** (todo exige JWT).
- Cada módulo interno valida además el **rol** del usuario.
- La **API pública** usa API Keys revocables e independientes del back office,
  con límite de peticiones por consumidor.
- La **documentación** (Swagger) solo es visible para usuarios autenticados.
- El **webhook de Toka** (`/api/webhooks/toka/payment/`) se valida con un secreto
  compartido en el header `X-Toka-Signature` (uso servidor-a-servidor).
